(function ($) {
 "use strict";
 
 /* tooltip */
 $('[data-toggle="tooltip"]').tooltip();
    
    
 /* meanmenu */
 
 $('nav#mobile_menu_active').meanmenu({
		meanScreenWidth: "767",
		meanMenuContainer: '.mobile_menu',
	});
 
 
 
 
 
})(jQuery);  