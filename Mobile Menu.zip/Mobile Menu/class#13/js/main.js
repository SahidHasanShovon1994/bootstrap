(function ($) {
 "use strict";
 
 /* meanmenu */
 
 	$('nav#mobile-menu-active').meanmenu({
		meanScreenWidth: "767",
		meanMenuContainer: ".mobile-menu",
	});
 
 
})(jQuery);  